Run Setup.exe
Game is located on desktop and in Start menu under Run DevilApproaches