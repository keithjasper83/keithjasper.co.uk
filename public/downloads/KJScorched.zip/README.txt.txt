Run Setup.exe
Install app
Start menu icon is named KJScorched Demo